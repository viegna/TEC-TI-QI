-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE Cliente (
data_nas DATETIME,
rg CHAR(8),
cod_cliente INTEGER PRIMARY KEY,
telefone CHAR(12),
nome_cliente VARCHAR(30),
inscricao NUMERIC(5)
)

CREATE TABLE Acidentes (
descricao VARCHAR(255),
data DATETIME,
hora DATETIME,
local VARCHAR(25),
id_acidente INTEGER PRIMARY KEY
)

CREATE TABLE Contrato+endereco (
certificado VARCHAR(8),
ano DATETIME,
apolice NUMERIC(5),
segurado VARCHAR(40),
seguradora VARCHAR(40),
placa VARCHAR(7),
chassi CHAR(17),
modelo VARCHAR(25),
marca VARCHAR(25),
premio_liquido DECIMAL(10),
iof DECIMAL(10),
premio_total DECIMAL(10),
forma_pagamento VARCHAR(15),
vencimento DATETIME,
cidade VARCHAR(25),
cobertura_pais VARCHAR(30),
processo_susep VARCHAR(15),
data DATETIME,
cod_contrato INTEGER PRIMARY KEY,
vigencia DATETIME,
pais VARCHAR(25),
cod_cliente INTEGER,
cod_funcionario INTEGER,
numero VARCHAR(7),
rua VARCHAR(25),
bairro VARCHAR(15),
cod_endereco NUMERIC(10),
estado CHAR(5),
-- Erro: nome do campo duplicado nesta tabela!
cidade VARCHAR(25),
FOREIGN KEY(cod_cliente) REFERENCES Cliente (cod_cliente)
)

CREATE TABLE Motoristas (
cnh CHAR(11),
rg CHAR(9),
cpf CHAR(11),
data_nasc DATETIME,
endereco VARCHAR(60),
telefone CHAR(12),
nome VARCHAR(40),
idade NUMERIC(3),
cad_motorista INTEGER PRIMARY KEY,
cod_veiculo INTEGER(1)
)

CREATE TABLE Carro (
placa CHAR(7),
cor VARCHAR(15),
observacoes VARCHAR(255),
cod_renavam INTEGER,
cod_veiculo integer(1) PRIMARY KEY,
modelo VARCHAR(30),
cod_cliente INTEGER,
FOREIGN KEY(cod_cliente) REFERENCES Cliente (cod_cliente)
)

CREATE TABLE Funcionario (
rg CHAR(10),
data_admissao DATETIME,
endereco VARCHAR(60),
cod_funcionario INTEGER PRIMARY KEY,
inscricao_est Texto(1),
endereco1 Texto(1),
gerente Texto(1),
cnpj Texto(1),
numero_filial Texto(1),
telefone Texto(1),
data_inauguracao Texto(1),
nome VARCHAR(35),
funcao VARCHAR(25),
cpf CHAR(11),
telefones CHAR(12)
)

CREATE TABLE Cliente_fisico (
cli_fisico INTEGER PRIMARY KEY,
cpf CHAR(11),
cod_cliente INTEGER,
FOREIGN KEY(cod_cliente) REFERENCES Cliente (cod_cliente)
)

CREATE TABLE Cliente_juridico (
cli_juridico INTEGER PRIMARY KEY,
cnpj CHAR(14),
cod_cliente INTEGER,
FOREIGN KEY(cod_cliente) REFERENCES Cliente (cod_cliente)
)

CREATE TABLE endereco (
endereco_PK INTEGER PRIMARY KEY,
cep CHAR(8),
numero INTEGER,
rua VARCHAR(15),
cod_cliente_FK INTEGER,
FOREIGN KEY(cod_cliente_FK) REFERENCES Cliente (cod_cliente)
)

CREATE TABLE car_aci (
cod_veiculo Texto(1),
id_acidente INTEGER,
FOREIGN KEY(cod_veiculo) REFERENCES Carro (cod_veiculo),
FOREIGN KEY(id_acidente) REFERENCES Acidentes (id_acidente)
)

CREATE TABLE aci_mo (
cad_motorista INTEGER,
id_acidente INTEGER,
FOREIGN KEY(cad_motorista) REFERENCES Motoristas (cad_motorista),
FOREIGN KEY(id_acidente) REFERENCES Acidentes (id_acidente)
)

ALTER TABLE Contrato+endereco ADD FOREIGN KEY(cod_funcionario) REFERENCES Funcionario (cod_funcionario)
ALTER TABLE Motoristas ADD FOREIGN KEY(cod_veiculo) REFERENCES Carro (cod_veiculo)
