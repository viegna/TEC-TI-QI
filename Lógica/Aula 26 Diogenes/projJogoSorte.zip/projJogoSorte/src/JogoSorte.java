public class JogoSorte {
    private byte numeroUsuario;
    private byte numeroSorteado;
    
    //metodo construtor
    public JogoSorte(){
        
            this.numeroSorteado = (byte)(Math.random()*5+1);
    }
    
    //set e get
    public byte getNumeroUsuario() {
        return numeroUsuario;
    }

    public void setNumeroUsuario(byte numeroUsuario) {
        this.numeroUsuario = numeroUsuario;
    }
    
    //metodos
    //to string

    @Override
    public String toString() {
        return "Jogo da Sorte! \nNumero Sorteado: " + this.numeroSorteado + " \nNumero do Usuario: " + this.numeroUsuario ;
        
    }
    
    public boolean verificarSeVenceu(){
        if(this.numeroUsuario==this.numeroSorteado){
            return  true;
        }else{
            return false;
        }
    }
            
    
    
}