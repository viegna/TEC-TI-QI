//Import para limpar tela: - coloca no inínio da classe Main - junto com import do scanner:
import java.awt.AWTException;
import java.awt.Robot;
import java.util.Scanner;

/**
 *
 * @author Tio Rudi && Tio Diox
 */
public class Main {
    public static void main(String[] args) {
        Scanner ler=new Scanner(System.in);
        
    //variaveis
    byte menu;
    int contVitorias = 0;
    int contTentativas = 0;

    do{
        
        System.out.println("*----------------------*");
        System.out.println("|      1.  JOGAR       |");
        System.out.println("|    2. INSTRUÇÕES     |");
        System.out.println("|      0. SAIR         |");
        System.out.println("*----------------------*");
        System.out.print("--->");
        menu=ler.nextByte();
        
        switch(menu){
            case 1:
                JogoSorte js1=new JogoSorte();
                do{
                    limparTela();
                    System.out.println("Escolha um número de 1 a 5!");
                    js1.setNumeroUsuario(ler.nextByte());
                    if(js1.getNumeroUsuario()<=0 || js1.getNumeroUsuario()>5){
                        System.out.println("\nErro!");
                    }
                    
                }while(js1.getNumeroUsuario()<=0 || js1.getNumeroUsuario()>5);
                contTentativas++;
              
                System.out.println(js1.toString());
                if(js1.verificarSeVenceu()){
                    
                    System.out.println("!!PARABÉNS CABEÇÃO!! Você venceu. ");
                    contVitorias++;
                }else{
                    System.out.println("!!You lose!!");
                }
                
                break;
            case 2:
                limparTela();
                System.out.println("*-------------------*");
                System.out.println("|     INSTRUÇÕES    |");
                System.out.println("*-------------------*");
                System.out.println("O usuáio escolhe um nº de 1 a 5;"
                                 + "\nA máquina sorteia automaticamente um número;\nSe os nºs forem iguais o usuário ganha;"
                                + "\nSe os nºs forem diferentes usuário perde;");
                break;
            case 0:
                
                limparTela();
                System.out.println("*---------------------------------*");
                System.out.println("|           VOLTE SEMPRE!         |");
                System.out.println("*---------------------------------*");
                System.out.println("Adiós! -Tio Diox");
                System.out.println("!!Hasta la vista!! <BABY> -Tio Rudi");
                System.out.print("Tentativas: "+contTentativas+" Vitórias: "+contVitorias);
                
            default:
                
                break;
             }
        }while(menu!=0);
    }
    //Método para limpar tela:
    //Limpar tela:
    public static void limparTela() {
        try {
            Robot pressbot = new Robot();
            pressbot.keyPress(17);
            pressbot.keyPress(76);
            pressbot.keyRelease(17);
            pressbot.keyRelease(76);
        } catch (AWTException awte) {
        }
        try {
            Thread.sleep(20);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }//fim do limparTela

//Abaixo vai a chave final do main
}
    

    