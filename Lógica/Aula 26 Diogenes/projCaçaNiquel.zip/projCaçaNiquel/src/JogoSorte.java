public class JogoSorte {
    public byte numeroSorteado1;
    public byte numeroSorteado2;
    public byte numeroSorteado3;
    //set e get
    
    //to string
    
    public void jogar(){
          this.numeroSorteado1 = (byte) (Math.random()*3+1);
          this.numeroSorteado2 = (byte) (Math.random()*3+1);
          this.numeroSorteado3 = (byte) (Math.random()*3+1);
    }
    
    public boolean verSeGanhou(){
         if(this.numeroSorteado1==this.numeroSorteado2&&this.numeroSorteado3==this.numeroSorteado1){
            return true;
        }else{
            return false;
        }
    }
        
        
        //
 

    @Override
        public String toString() {
            String desenho1;
        switch (this.numeroSorteado1) {
            case 1:
                desenho1 = " ♥ ";
                break;
            case 2:
                desenho1 = " ☻ ";
                break;
            default:
                desenho1 = " ☼ ";
                break;
        }
            String desenho2;
        switch (this.numeroSorteado2) {
            case 1:
                desenho2 = " ♥ ";
                break;
            case 2:
                desenho2 = " ☻ ";
                break;
            default:
                desenho2 = " ☼ ";
                break;
        }
            String desenho3;
        switch (this.numeroSorteado3) {
            case 1:
                desenho3 = " ♥ ";
                break;
            case 2:
                desenho3 = " ☻ ";
                break;
            default:
                desenho3 = " ☼ ";
                break;
        }
            return "\nNumeros Sorteado: " +desenho1 + " - " + desenho2 + " - " + desenho3;
        
        }
    }