public class Aluno {
    // atributos
    private String nome;
    private String nomeMae;
    private String cpf;
    private String rg;
    private String escola;
    
    
    //set e get

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeMae() {
        return nomeMae;
    }

    public void setNomeMae(String nomeMae) {
        this.nomeMae = nomeMae;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEscola() {
        return escola;
    }

    public void setEscola(String escola) {
        this.escola = escola;
    }
    
    // metodo construtor
        public Aluno(){
        this.escola="FL05-Gravataí";
    }
    
    
    
    
    //to string

    @Override
    public String toString() {
        return "Nome:" + nome + "\nNome da Mae:" + nomeMae + "\nCPF:" + cpf + "\nRG:" + rg + "\nEscola:" + escola;
    }
    
    
    
}
