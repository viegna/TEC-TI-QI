
import java.util.Scanner;

/**
 *
 * @author Diógenes
 */
public class Main {
    public static void main(String[] args) {
    Scanner ler= new Scanner(System.in);
    Aluno a1= new Aluno();
    
    //pede e lê
        System.out.println("Digite o nome do aluno: ");
        a1.setNome(ler.nextLine());
        System.out.println("Digite o nome da mãe: ");
        a1.setNomeMae(ler.nextLine());
        System.out.println("Digite o CPF: ");
        a1.setCpf(ler.next());
        System.out.println("Digite o RG: ");
        a1.setRg(ler.next());
        
        
        System.out.println("RESPOSTAS");
        System.out.println(a1);
        
        
        
    }
    
    
}
