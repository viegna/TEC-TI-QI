
/**
 * Escreva a descrição da classe Main aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        Scanner ler=new Scanner(System.in);
        //variaveis
        String nome;
        String cpf;
        String cargo;
        double valorHora;
        double horasTrabalhadas;
        double valorTotalPassagem;
        int quantidadeDependentes;
        byte tipoInsalubridade;
        double totalInsalubridade;
        double salarioBruto;
        double valeTransporte;
        double passagemCobrada;
        double beneficioDependente;
       
        String resposta;
        //pede e le
        System.out.println("Digite o nome do funcionŕrio: ");
        nome=ler.nextLine();
        System.out.println("Digite o CPF: ");
        cpf=ler.nextLine();
        System.out.println("Digite o valor da hora trabalhada: ");
        valorHora=ler.nextDouble();
        System.out.println("Digite as horas trabalhadas: ");
        horasTrabalhadas=ler.nextDouble();
        System.out.println("Digite o valor total da passagem: ");
        valorTotalPassagem=ler.nextDouble();
        System.out.println("Digite a quantidade de dependentes: ");
        quantidadeDependentes=ler.nextInt();
        System.out.println("Digite o tipo de insalubridade: ");
        System.out.println("1 - Nenhum\n2-Mínimo\n3 - Média\n4 - Máxima");
        tipoInsalubridade=ler.nextByte();
        
        //calculando salario bruto
        salarioBruto=valorHora*horasTrabalhadas;
        //calculando valeTransporte
        valeTransporte=salarioBruto*0.06;
        if(valeTransporte>valorTotalPassagem){
            passagemCobrada=valorTotalPassagem;
        }else{
            passagemCobrada=valeTransporte;
        }
        //calculando Salario Familia
        if(salarioBruto<=725.02){
            beneficioDependente=37.18*quantidadeDependentes;
        }else if(salarioBruto>=753.03 && salarioBruto<=1089.72){
            beneficioDependente=26.2*quantidadeDependentes;
        }else{
            beneficioDependente=0;
        }
        
        //calculando insalubridade
        
        switch(tipoInsalubridade){
            case 1:
            totalInsalubridade=0;
            break;
            case 2:
            totalInsalubridade=868*0.1;
            break;
            case 3:
            totalInsalubridade=868*0.2;
            case 4:
            totalInsalubridade=868*0.4;
            break;
            default:
            totalInsalubridade=0;
        }
        //calculando inss
        if(salarioBruto<=1317.07){
        }
        // Faltou terminas a E, que é INSS e a F, que é o salario liquido.
        //Qualquer coisa me chama que eu ajudo assim que puder mlk vlw flw.
    }
}
